# FabricPlayerViewerMod

Fully working mod project with Gradle wrapper.